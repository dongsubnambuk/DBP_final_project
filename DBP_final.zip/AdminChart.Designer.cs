﻿namespace DBP_final
{
    partial class 통계
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend4 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chart3 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chart4 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.성적분포 = new System.Windows.Forms.TabPage();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.강의과목수 = new System.Windows.Forms.TabPage();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.과목당학생수 = new System.Windows.Forms.TabPage();
            this.listBox3 = new System.Windows.Forms.ListBox();
            this.성적우수학생 = new System.Windows.Forms.TabPage();
            this.listBox4 = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart4)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.성적분포.SuspendLayout();
            this.강의과목수.SuspendLayout();
            this.과목당학생수.SuspendLayout();
            this.성적우수학생.SuspendLayout();
            this.SuspendLayout();
            // 
            // chart1
            // 
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(6, 3);
            this.chart1.Name = "chart1";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.chart1.Series.Add(series1);
            this.chart1.Size = new System.Drawing.Size(758, 184);
            this.chart1.TabIndex = 0;
            this.chart1.Text = "chart1";
            // 
            // chart2
            // 
            chartArea2.Name = "ChartArea1";
            this.chart2.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            this.chart2.Legends.Add(legend2);
            this.chart2.Location = new System.Drawing.Point(6, 4);
            this.chart2.Name = "chart2";
            series2.ChartArea = "ChartArea1";
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            this.chart2.Series.Add(series2);
            this.chart2.Size = new System.Drawing.Size(755, 184);
            this.chart2.TabIndex = 1;
            this.chart2.Text = "chart2";
            // 
            // chart3
            // 
            chartArea3.Name = "ChartArea1";
            this.chart3.ChartAreas.Add(chartArea3);
            legend3.Name = "Legend1";
            this.chart3.Legends.Add(legend3);
            this.chart3.Location = new System.Drawing.Point(6, 4);
            this.chart3.Name = "chart3";
            series3.ChartArea = "ChartArea1";
            series3.Legend = "Legend1";
            series3.Name = "Series1";
            this.chart3.Series.Add(series3);
            this.chart3.Size = new System.Drawing.Size(758, 184);
            this.chart3.TabIndex = 2;
            this.chart3.Text = "chart3";
            // 
            // chart4
            // 
            chartArea4.Name = "ChartArea1";
            this.chart4.ChartAreas.Add(chartArea4);
            legend4.Name = "Legend1";
            this.chart4.Legends.Add(legend4);
            this.chart4.Location = new System.Drawing.Point(6, 6);
            this.chart4.Name = "chart4";
            series4.ChartArea = "ChartArea1";
            series4.Legend = "Legend1";
            series4.Name = "Series1";
            this.chart4.Series.Add(series4);
            this.chart4.Size = new System.Drawing.Size(755, 184);
            this.chart4.TabIndex = 3;
            this.chart4.Text = "chart4";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.성적분포);
            this.tabControl1.Controls.Add(this.강의과목수);
            this.tabControl1.Controls.Add(this.과목당학생수);
            this.tabControl1.Controls.Add(this.성적우수학생);
            this.tabControl1.Location = new System.Drawing.Point(12, 23);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(775, 379);
            this.tabControl1.TabIndex = 4;
            // 
            // 성적분포
            // 
            this.성적분포.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(242)))), ((int)(((byte)(246)))));
            this.성적분포.Controls.Add(this.listBox1);
            this.성적분포.Controls.Add(this.chart1);
            this.성적분포.Location = new System.Drawing.Point(4, 22);
            this.성적분포.Name = "성적분포";
            this.성적분포.Padding = new System.Windows.Forms.Padding(3);
            this.성적분포.Size = new System.Drawing.Size(767, 353);
            this.성적분포.TabIndex = 0;
            this.성적분포.Text = "학기별성적분포";
            // 
            // listBox1
            // 
            this.listBox1.Font = new System.Drawing.Font("굴림", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 27;
            this.listBox1.Location = new System.Drawing.Point(6, 194);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(758, 166);
            this.listBox1.TabIndex = 1;
            // 
            // 강의과목수
            // 
            this.강의과목수.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(242)))), ((int)(((byte)(246)))));
            this.강의과목수.Controls.Add(this.listBox2);
            this.강의과목수.Controls.Add(this.chart2);
            this.강의과목수.Location = new System.Drawing.Point(4, 22);
            this.강의과목수.Name = "강의과목수";
            this.강의과목수.Padding = new System.Windows.Forms.Padding(3);
            this.강의과목수.Size = new System.Drawing.Size(767, 353);
            this.강의과목수.TabIndex = 1;
            this.강의과목수.Text = "교수별강의과목수";
            // 
            // listBox2
            // 
            this.listBox2.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 24;
            this.listBox2.Location = new System.Drawing.Point(6, 195);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(755, 124);
            this.listBox2.TabIndex = 2;
            // 
            // 과목당학생수
            // 
            this.과목당학생수.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(242)))), ((int)(((byte)(246)))));
            this.과목당학생수.Controls.Add(this.listBox3);
            this.과목당학생수.Controls.Add(this.chart3);
            this.과목당학생수.Location = new System.Drawing.Point(4, 22);
            this.과목당학생수.Name = "과목당학생수";
            this.과목당학생수.Padding = new System.Windows.Forms.Padding(3);
            this.과목당학생수.Size = new System.Drawing.Size(767, 353);
            this.과목당학생수.TabIndex = 2;
            this.과목당학생수.Text = "과목당학생수";
            // 
            // listBox3
            // 
            this.listBox3.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.listBox3.FormattingEnabled = true;
            this.listBox3.ItemHeight = 24;
            this.listBox3.Location = new System.Drawing.Point(6, 195);
            this.listBox3.Name = "listBox3";
            this.listBox3.Size = new System.Drawing.Size(758, 124);
            this.listBox3.TabIndex = 3;
            // 
            // 성적우수학생
            // 
            this.성적우수학생.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(242)))), ((int)(((byte)(246)))));
            this.성적우수학생.Controls.Add(this.listBox4);
            this.성적우수학생.Controls.Add(this.chart4);
            this.성적우수학생.Location = new System.Drawing.Point(4, 22);
            this.성적우수학생.Name = "성적우수학생";
            this.성적우수학생.Padding = new System.Windows.Forms.Padding(3);
            this.성적우수학생.Size = new System.Drawing.Size(767, 353);
            this.성적우수학생.TabIndex = 3;
            this.성적우수학생.Text = "성적우수학생";
            // 
            // listBox4
            // 
            this.listBox4.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.listBox4.FormattingEnabled = true;
            this.listBox4.ItemHeight = 24;
            this.listBox4.Location = new System.Drawing.Point(6, 196);
            this.listBox4.Name = "listBox4";
            this.listBox4.Size = new System.Drawing.Size(755, 124);
            this.listBox4.TabIndex = 4;
            // 
            // 통계
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(242)))), ((int)(((byte)(246)))));
            this.ClientSize = new System.Drawing.Size(789, 450);
            this.Controls.Add(this.tabControl1);
            this.Name = "통계";
            this.Text = "통계";
            this.Load += new System.EventHandler(this.통계_Load);
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart4)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.성적분포.ResumeLayout(false);
            this.강의과목수.ResumeLayout(false);
            this.과목당학생수.ResumeLayout(false);
            this.성적우수학생.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart2;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart3;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart4;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage 성적분포;
        private System.Windows.Forms.TabPage 강의과목수;
        private System.Windows.Forms.TabPage 과목당학생수;
        private System.Windows.Forms.TabPage 성적우수학생;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.ListBox listBox3;
        private System.Windows.Forms.ListBox listBox4;
    }
}